#ifndef __SHOW_H
#define __SHOW_H
#include "sys.h"

void pcShow(void);

#endif
